# py写源技能 v9.5.2 全量补丁说明

## 解决的问题

建源工坊反复出现：
1. 输出缺少完整 `class Spider`，自动套回本地骨架
2. 真跑首页/推荐 0 条，修 3 轮仍失败
3. 已识别 mytheme / `?cates-` 路由，却仍套标准 `/index.php/vod/` 模板

根因：技能矩阵提到了非标准路由，但**缺少对应可执行模板**；静态门禁未禁止「骨架回退交付」；真跑 0 条时修复策略不针对列表选择器。

## 本包变更

| 文件 | 说明 |
|------|------|
| `templates/code/maccms_mytheme.py` | **新增** 非标准伪静态完整模板（cates/vodss/plays + myui 列表 + iframe url= 解析） |
| `templates/code/example_chanmea.py` | 实测通过样例（chanmea.cc，首页 38 条，播放直链 m3u8） |
| `strategies/maccms_mytheme_route.md` | 强制装载条件与排障 |
| `SKILL.md` | 增加 **5.1 硬门禁**：禁止骨架交付、0 条未完成、mytheme 强制模板 |
| `validators/static_check.py` | FATAL 级：缺 Spider / 缺 homeVideoContent / 骨架标记 |
| `validators/gates.md` | 同步硬门禁 |

## 接入建源工坊

1. 用本目录整体替换原 `py写源技能`（或 py9.5.1 技能包解压目录）
2. 确保技能根目录名为明文 `py写源技能`（禁止 URL 编码目录名）
3. 重新加载技能后写源；命中 mytheme 站应自动走 `maccms_mytheme.py`

## 验证

对 https://chanmea.cc 用 example 或 mytheme 模板真跑：
- homeVideoContent > 0
- categoryContent > 0  
- playerContent 返回 m3u8 且 parse=0


## OneNav 导航目录站识别补丁（适用于 v9.5.2）
- 新增 `strategies/wordpress_onenav_directory.md`：识别 WordPress + OneNav 外链导航站，防止把外链卡片伪装成视频数据。
- `SKILL.md` 增加内容归属预检和 OneNav 分诊矩阵。
- `validators/gates.md` 增加首页/推荐均为 0 条时的导航站分诊，不再机械进入三轮 selector 修复。
- 对 `https://www.kldaohang1.com/` 这类目录站，建议终止 Spider 生成，要求用户指定目录中的一个真实影视目标站。


## Agent 工作法补丁（2.37，适用于 v9.5.2 + OneNav）
- 新增 `strategies/agent_workflow.md`：提炼 Eta-por（Oo0520/Eta-por）与 LineCodePro（LangLang03/LineCodePro）的 Agent 做法——计划→最小改动→实测验证→证据汇报；基线与回滚；连续两轮同因失败即停；上下文预算（一个站点只装一个主模板 + 一个匹配策略）。
- `SKILL.md` 增加 5.2 Agent 工作法引用；App 侧 AiSkillPack 常驻加载 agent_workflow，不依赖站点分诊。
- OneNav 与 Agent 两补丁同属 2.37 技能包，随 AVBox 2.37 交付。


## Agent 工具补丁（2.38，完整工坊）
- `strategies/agent_workflow.md`“工坊提供的工具”一节升级为完整工坊：生成 + 修源都走工具循环，工具 10 个——fetch_url / read_skill（按需读技能模块，如 maccms_mytheme_code、maccms_example）/ write_source（写工作区 source.py）/ static_check / run_six_api（真跑工作区 source.py 六接口）/ read_file / write_file / edit_file / run_spider / list_files（提示词协议 tool_call JSON，沙箱内自动放行）。
- 工作区：每次建源一个目录（filesDir/ai_workshop/<jobId>/），放 source.py（唯一主文件）、meta.json、log.txt；source.py 跑完保留。
- 循环上限 8 回合；同一错误指纹连续 3 次即停并保留基线；完成前必须自己调 static_check 与 run_six_api 验过。
- App 侧 AiAssistPanel：写源由 generateWithAgent（工具循环）接手，修源由 repairWithAgent（同套工具循环）接手；MacCMS 模板优先与 OneNav 分诊仍在 Agent 之前。
