# MacCMS mytheme 非标准伪静态路由策略 v9.5.2

## 适用条件

命中任一即装载本策略，并强制使用 `templates/code/maccms_mytheme.py` 作为主代码模板：

- HTML 含 `/template/mytheme/` 或 `myui-vodlist` / `myui-vodlist__box` / `myui-vodlist__thumb`
- 链接形态为 `?cates-{tid}.html`、`?cates-{tid}-{page}.html`、`?vodss-{id}.html`、`?plays-{id}-{sid}-{nid}.html`
- 播放页 iframe 形如 `.../m3u8/?url=真实m3u8` 或页内 `player_data` / `var now`

## 关键约束

1. **禁止**再套 `maccms_v10.py` 的 `/index.php/vod/show`、`/index.php/vod/detail`、`/index.php/vod/play` 路径，除非实测确认站点同时存在该路径且返回数据。
2. 列表选择器优先级：
   - `//div[contains(@class,"myui-vodlist__box")]`
   - 其次 `//a[contains(@class,"myui-vodlist__thumb")]`
   - 封面优先从 `a/@style` 的 `background:url(...)` 提取，其次 `img/@data-original`
3. 分类 ID 从导航 `?cates-数字` 提取；分页为 `?cates-{tid}-{page}.html`。
4. 详情多线路：`#playlist1`、`#playlist2`... 对应 sid；线路名从 tab 文本取。
5. 播放解析顺序：iframe src 的 `url=` 参数 → `player_data.url` → `var now` → 页内 `.m3u8`。禁止把 `?plays-*.html` 当直链返回 `parse:0`。
6. 真跑 `homeVideoContent` 必须 >0 条；若为 0，先打印选择器命中数与首页 HTML 片段再改选择器，禁止直接换骨架。

## 与主模板关系

`maccms_mytheme.py` 已内置完整六接口与 session/缓存。生成时只需替换：

- `self.host`
- `self.categories`（可从首页导航实测填充，也可保留默认后 `_discover_categories`）
- 如站点分页/搜索路径不同，只改 `self.route` 字典

其余逻辑禁止无故删减，尤其 `_extract_list` 与 `playerContent` 二次解析。

## 排障速查

| 现象 | 处理 |
|------|------|
| 首页 0 条 | 检查是否误用 videopic 选择器；改为 myui-vodlist__box；确认 HTML 非空 |
| 分类 0 条 | 确认 tid 与 `?cates-{tid}` 一致；page>1 用 `cates-{tid}-{page}` |
| 播放仍是 html | 解析 iframe url=；加 Referer |
| 缺少 Spider 类 | 整文件重生成，禁止骨架回退交付 |
