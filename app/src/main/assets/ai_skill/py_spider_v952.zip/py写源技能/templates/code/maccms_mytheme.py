# coding=utf-8
import json
import re
import time
from urllib.parse import urljoin, urlparse, parse_qs
import requests
try:
    from lxml import etree
except Exception:
    etree = None
from base.spider import Spider


class Spider(Spider):
    def getName(self):
        return "mytheme"

    def init(self, extend=""):
        self.name = "mytheme"
        self.host = "https://example.com"
        self.backup_hosts = []
        self.shield = []
        if isinstance(extend, str) and extend.strip():
            s = extend.strip()
            if s.startswith("{"):
                try:
                    cfg = json.loads(s)
                    self.host = cfg.get("host", self.host).rstrip("/")
                    self.backup_hosts = cfg.get("backup_hosts", []) or []
                    self.shield = cfg.get("shield", []) or []
                except Exception:
                    pass
            elif "://" in s:
                self.host = s.rstrip("/")
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": self.host + "/",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9",
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        self.categories = []
        self._cache = {}
        self._cache_ttl = 30
        self._cache_max = 120
        self.route = {
            "category": "/?cates-{tid}.html",
            "category_page": "/?cates-{tid}-{page}.html",
            "detail": "/?vodss-{id}.html",
            "play": "/?plays-{id}-{sid}-{nid}.html",
            "search": "/index.php/vod/search.html",
        }

    def _set_host(self, h):
        self.host = h.rstrip("/")
        self.headers["Referer"] = self.host + "/"
        self.session.headers.update(self.headers)

    def _hosts(self):
        return list(dict.fromkeys([self.host] + self.backup_hosts + self.shield))

    def _fix(self, url):
        if not url:
            return ""
        if str(url).startswith("http"):
            return url
        return urljoin(self.host + "/", str(url).lstrip("/"))

    def _get(self, url, depth=0):
        if depth > 2:
            return ""
        url = self._fix(url)
        now = time.time()
        if url in self._cache and now - self._cache[url][0] < self._cache_ttl:
            return self._cache[url][1]
        for h in self._hosts():
            try:
                target = url
                if h != self.host and url.startswith(self.host):
                    target = h + url[len(self.host):]
                r = self.session.get(target, headers=self.headers, timeout=15, verify=False)
                r.encoding = r.apparent_encoding or "utf-8"
                if r.status_code == 200 and r.text and len(r.text) > 400:
                    if h != self.host:
                        self._set_host(h)
                    if len(self._cache) >= self._cache_max:
                        self._cache.pop(next(iter(self._cache)))
                    self._cache[url] = (now, r.text)
                    return r.text
            except Exception:
                continue
        return ""

    def _tree(self, html):
        if etree is None or not html:
            return None
        try:
            return etree.HTML(html)
        except Exception:
            return None

    def _text(self, node):
        if node is None:
            return ""
        return " ".join("".join(node.xpath(".//text()")).split())

    def _is_media(self, url):
        if not url or not str(url).startswith("http"):
            return False
        u = urlparse(str(url))
        if re.search(r"\.(?:html?|php)(?:$|[?#/])", u.path or "", re.I):
            return False
        return bool(re.search(r"\.(?:m3u8|mp4)(?:$|[?#])", u.path or "", re.I) or "m3u8" in (u.path or "").lower())

    def _probe_media(self, url):
        if not self._is_media(url):
            return ""
        try:
            r = self.session.get(url, headers={**self.headers, "Range": "bytes=0-2047"}, timeout=12, verify=False, stream=True)
            try:
                data = next(r.iter_content(2048), b"")
                ctype = (r.headers.get("Content-Type") or "").lower()
                if r.ok and (b"#EXTM3U" in data or "mpegurl" in ctype or "vnd.apple" in ctype or "video/" in ctype or b"ftyp" in data[:32]):
                    return r.url or url
            finally:
                r.close()
        except Exception:
            pass
        return url if self._is_media(url) else ""

    def _extract_list(self, html):
        tree = self._tree(html)
        out, seen = [], set()
        if tree is None:
            return out
        boxes = tree.xpath('//div[contains(@class,"myui-vodlist__box")]')
        if not boxes:
            boxes = tree.xpath('//a[contains(@class,"myui-vodlist__thumb")]')
        if not boxes:
            boxes = tree.xpath('//div[contains(@class,"myui-vodlist")]//a[contains(@href,"vodss-") or contains(@href,"/vod/detail")]')
        for box in boxes:
            try:
                a = box if getattr(box, "tag", "") == "a" else (box.xpath('.//a[contains(@class,"myui-vodlist__thumb")]') or box.xpath(".//a[@href]") or [None])[0]
                if a is None:
                    continue
                href = a.get("href") or ""
                m = re.search(r"(?:vodss-|/vod/detail/id/)(\d+)", href)
                if not m:
                    continue
                vid = m.group(1)
                if vid in seen:
                    continue
                seen.add(vid)
                name = a.get("title") or ""
                if not name:
                    tnode = box.xpath('.//h4[contains(@class,"title")]//a') or box.xpath('.//*[contains(@class,"title")]//a')
                    if tnode:
                        name = self._text(tnode[0]) or tnode[0].get("title") or ""
                if not name:
                    name = self._text(a)
                pic = ""
                style = a.get("style") or ""
                mstyle = re.search(r"url\(([^)]+)\)", style)
                if mstyle:
                    pic = mstyle.group(1).strip("'\" ")
                if not pic:
                    imgs = a.xpath(".//img/@data-original") or a.xpath(".//img/@data-src") or a.xpath(".//img/@src")
                    if imgs:
                        pic = imgs[0]
                if not pic:
                    pic = a.get("data-original") or ""
                remarks = ""
                tags = box.xpath('.//*[contains(@class,"pic-tag")]/text()') or box.xpath('.//*[contains(@class,"pic-text")]/text()')
                if tags:
                    remarks = "".join(tags).strip()
                out.append({"vod_id": vid, "vod_name": (name or "").strip(), "vod_pic": self._fix(pic), "vod_remarks": remarks})
            except Exception:
                continue
        return out

    def _discover_categories(self, html):
        tree = self._tree(html)
        if tree is None:
            return
        seen = set()
        for a in tree.xpath('//a[contains(@href,"cates-") or contains(@href,"/vod/type") or contains(@href,"/vod/show")]'):
            href = a.get("href") or ""
            name = self._text(a)
            m = re.search(r"cates-(\d+)|type_id[=/](\d+)|/type/(\d+)", href)
            if not m or not name or name in ("更多", "首页", "Home"):
                continue
            tid = next(g for g in m.groups() if g)
            if tid in seen:
                continue
            seen.add(tid)
            self.categories.append({"type_id": tid, "type_name": name})

    def homeContent(self, filter):
        if not self.categories:
            html = self._get(self.host + "/")
            self._discover_categories(html)
        return {"class": self.categories or [
            {"type_id": "1", "type_name": "电影"},
            {"type_id": "15", "type_name": "连续剧"},
            {"type_id": "24", "type_name": "综艺"},
            {"type_id": "30", "type_name": "动漫"},
        ], "filters": {}, "list": []}

    def homeVideoContent(self):
        html = self._get(self.host + "/")
        return {"list": self._extract_list(html)}

    def categoryContent(self, tid, pg, filter, extend):
        page = int(pg or 1)
        if page <= 1:
            path = self.route["category"].format(tid=tid)
        else:
            path = self.route["category_page"].format(tid=tid, page=page)
        html = self._get(self.host + path)
        items = self._extract_list(html)
        pagecount = page + (1 if items else 0)
        tree = self._tree(html)
        if tree is not None:
            nums = []
            for a in tree.xpath('//ul[contains(@class,"myui-page")]//a') or tree.xpath('//*[contains(@class,"page")]//a'):
                href = a.get("href") or ""
                text = self._text(a)
                m = re.search(r"cates-\d+-(\d+)\.html|/page/(\d+)|page[=/](\d+)", href)
                if m:
                    nums.append(int(next(g for g in m.groups() if g)))
                elif text.isdigit():
                    nums.append(int(text))
            if nums:
                pagecount = max(nums + [page])
        return {"list": items, "page": page, "pagecount": pagecount, "limit": len(items) or 40, "total": pagecount * (len(items) or 40)}

    def detailContent(self, ids):
        vid = str(ids[0]) if isinstance(ids, list) else str(ids)
        html = self._get(self.host + self.route["detail"].format(id=vid))
        tree = self._tree(html)
        if tree is None:
            return {"list": []}
        name = ""
        h1 = tree.xpath("//h1/text()")
        if h1:
            name = h1[0].strip()
        if not name:
            name = "".join(tree.xpath('//*[contains(@class,"title")]/text()')[:1]).strip()
        pic = ""
        imgs = tree.xpath('//*[contains(@class,"detail") or contains(@class,"content")]//img/@data-original') or tree.xpath("//img/@data-original") or tree.xpath("//img/@src")
        if imgs:
            pic = self._fix(imgs[0])
        play_from, play_url = [], []
        for sid in range(1, 10):
            nodes = tree.xpath(f'//div[@id="playlist{sid}"]//a')
            if not nodes:
                continue
            source = f"线路{sid}"
            tabs = tree.xpath(f'//a[contains(@href,"#playlist{sid}")]/text()') or tree.xpath(f'//*[contains(@href,"playlist{sid}")]/text()')
            if tabs:
                source = (tabs[0] or source).strip()
            eps = []
            for a in nodes:
                href = a.get("href") or ""
                if "plays-" not in href and "/vod/play" not in href:
                    continue
                et = self._text(a) or a.get("title") or "正片"
                eps.append(f"{et}${self._fix(href)}")
            if eps:
                play_from.append(source)
                play_url.append("#".join(eps))
        if not play_from:
            nodes = tree.xpath('//a[contains(@href,"plays-") or contains(@href,"/vod/play")]')
            eps = [f"{self._text(a) or '正片'}${self._fix(a.get('href') or '')}" for a in nodes if a.get("href")]
            if eps:
                play_from.append("默认")
                play_url.append("#".join(eps))
        return {"list": [{
            "vod_id": vid,
            "vod_name": name,
            "vod_pic": pic,
            "vod_remarks": "",
            "vod_content": "",
            "vod_play_from": "$$$".join(play_from),
            "vod_play_url": "$$$".join(play_url),
        }]}

    def searchContent(self, key, quick, pg="1"):
        page = int(pg or 1)
        html = ""
        try:
            r = self.session.get(self.host + self.route["search"], params={"wd": key, "page": page}, headers=self.headers, timeout=15, verify=False)
            r.encoding = r.apparent_encoding or "utf-8"
            html = r.text
        except Exception:
            pass
        if not html or len(html) < 400:
            html = self._get(f"{self.host}/?wd={key}&page={page}")
        items = self._extract_list(html)
        return {"list": items, "page": page, "pagecount": page + (1 if items else 0), "limit": len(items), "total": 0}

    def playerContent(self, flag, id, vipFlags):
        play_url = id if str(id).startswith("http") else self._fix(id)
        if self._is_media(play_url):
            real = self._probe_media(play_url)
            return {"parse": 0, "url": real or play_url, "header": json.dumps(self.headers)}
        html = self._get(play_url)
        real = ""
        ifr = re.search(r'<iframe[^>]+src=["\']([^"\']+)', html or "", re.I)
        if ifr:
            src = ifr.group(1).replace("&amp;", "&")
            qs = parse_qs(urlparse(src).query)
            if "url" in qs and qs["url"]:
                real = qs["url"][0]
            elif self._is_media(src):
                real = src
            else:
                real = self._resolve_from_page(src)
        if not real:
            m = re.search(r'player_data\s*=\s*(\{.*?\})', html or "", re.S)
            if m:
                try:
                    real = json.loads(m.group(1)).get("url") or ""
                except Exception:
                    pass
        if not real:
            m = re.search(r'(?:var\s+now|var\s+playurl)\s*=\s*["\']([^"\']+)', html or "")
            if m:
                real = m.group(1).replace("&amp;", "&")
        if not real:
            m3 = re.findall(r'https?://[^"\'<>\s]+\.m3u8[^"\'<>\s]*', html or "", re.I)
            if m3:
                real = m3[0].replace("&amp;", "&")
        real = self._fix(real) if real else ""
        if real and not self._is_media(real):
            real = self._resolve_from_page(real)
        if real and self._is_media(real):
            probed = self._probe_media(real)
            return {"parse": 0, "url": probed or real, "header": json.dumps(self.headers)}
        return {"parse": 1 if not real else 0, "url": real or play_url, "header": json.dumps(self.headers)}

    def _resolve_from_page(self, url, depth=0):
        if depth > 2 or not url:
            return ""
        url = self._fix(url)
        if self._is_media(url):
            return self._probe_media(url) or url
        html = self._get(url)
        if not html:
            return ""
        qs = parse_qs(urlparse(url).query)
        if "url" in qs and qs["url"] and self._is_media(qs["url"][0]):
            return qs["url"][0]
        ifr = re.search(r'<iframe[^>]+src=["\']([^"\']+)', html, re.I)
        if ifr:
            src = ifr.group(1).replace("&amp;", "&")
            q = parse_qs(urlparse(src).query)
            if "url" in q and q["url"]:
                return q["url"][0]
            return self._resolve_from_page(src, depth + 1)
        m3 = re.findall(r'https?://[^"\'<>\s]+\.m3u8[^"\'<>\s]*', html, re.I)
        return m3[0].replace("&amp;", "&") if m3 else ""
