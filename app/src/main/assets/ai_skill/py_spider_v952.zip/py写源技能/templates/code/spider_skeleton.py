# coding=utf-8
import re
from urllib.parse import urljoin, quote
import requests
from base.spider import Spider

class Spider(Spider):
    def getName(self):
        return "site"

    def init(self, extend=""):
        self.host = "https://example.com"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
            "Referer": self.host + "/",
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        self.categories = []

    def homeContent(self, filter):
        return {"class": self.categories, "filters": {}, "list": []}

    def homeVideoContent(self):
        return {"list": []}

    def categoryContent(self, tid, pg, filter, extend):
        return {"page": 1, "pagecount": 1, "limit": 0, "total": 0, "list": []}

    def detailContent(self, ids):
        return {"list": []}

    def searchContent(self, key, quick, pg="1"):
        return {"list": [], "page": 1}

    def playerContent(self, flag, id, vipFlags):
        return {"parse": 1, "url": "", "header": self.headers}

    def _get(self, url):
        try:
            r = self.session.get(url, headers=self.headers, timeout=15, verify=False, proxies=self.session.proxies or None)
            r.encoding = r.apparent_encoding or "utf-8"
            return r.text
        except Exception:
            return ""

    def _abs(self, url):
        if not url:
            return ""
        return urljoin(self.host + "/", url)

    def _is_media(self, url):
        if not url or not str(url).startswith("http"):
            return False
        return bool(re.search(r"\.(?:m3u8|mp4)(?:$|[?#])", str(url), re.I))

    def _probe_media(self, url):
        if not self._is_media(url):
            return ""
        try:
            r = self.session.get(url, headers=self.headers, timeout=12, verify=False, stream=True, proxies=self.session.proxies or None)
            ok = r.status_code < 400
            r.close()
            return url if ok else ""
        except Exception:
            return url if self._is_media(url) else ""
