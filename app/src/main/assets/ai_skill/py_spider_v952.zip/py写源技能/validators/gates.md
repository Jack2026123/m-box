# 验证与排错模块 v9.5

六接口（含 homeVideoContent）、统一契约检查和端到端验证是完成门槛。模板静态通过不等于站点完成；无目标 URL、真实响应或媒体样本时必须标记未验证。故障排查表和211经验速查用于失败定位。

# 验证流程

```python
import os
import sys
sys.path.insert(0, os.environ.get('SPIDER_ROOT', '/sdcard/Download'))
import 脚本名; s = 脚本名.Spider()
if hasattr(s, 'getName'): print("T4模式:", s.getName())
s.init("")
required = ['homeContent','homeVideoContent','categoryContent','detailContent','searchContent','playerContent']
missing = [m for m in required if not hasattr(s, m)]; print("缺少接口:", missing)
if missing: raise RuntimeError("六接口不完整")
print("首页:", s.homeContent(False)); print("推荐:", s.homeVideoContent())
r = s.searchContent("测试", "0"); print(len(r['list']), r['list'][0]['vod_name'] if r['list'] else "空")
if r['list']:
    d = s.detailContent([r['list'][0]['vod_id']]); v = d['list'][0] if d['list'] else None
    if v: print(v['vod_name'], v['vod_play_from']); pid = v['vod_play_url'].split('#')[0].split('$')[1] if '$' in v['vod_play_url'] else ''; p = s.playerContent("", pid, []); print(p.get('url','')[:80])
```

静态检查分两种模式：技能自带模板执行以下命令，占位域名显示 WARN：

```bash
python3 validators/static_check.py
```

HLS 主/子清单、key、ts 与 AES-128 必须用 `templates/lib/hls.py` 校验；图片魔数与 AES 解密用 `templates/lib/image.py`；folder/队列/episode 用 `templates/lib/folder.py`、`queues.py`、`episode.py`。

最终交付源还必须执行 `python3 validators/interface_check.py /path/to/source.py` 与 `python3 validators/behavior_check.py /path/to/source.py`（mock 六接口行为回归）；画像和 IR 实例必须分别执行 `python3 validators/schema_check.py schemas/site_profile.json profile.json` 与 `python3 validators/schema_check.py schemas/spider_ir.json spider_ir.json`。

最终交付源必须执行以下命令，任何占位域名或硬伤必须 FAIL：

```bash
python3 validators/static_check.py /path/to/source.py --final
```

---
# 故障排查

| 问题 | 方案 |
|------|------|
| `module 'xxx' has no attribute 'Spider'` | 创建Spider类 |
| 影视仓无法加载T4源 | type:4 + api地址正确 |
| 字幕不显示 | playerContent返回subs |
| 播放403 | playerContent返回header |
| shell 端没数据但浏览器能打开 | Python requests 不继承系统 VPN；加载 `strategies/proxy_network.md`，支持 `extend.proxy`、环境变量和本机代理端口探测 |
| localProxy/proxyPic 图片不显示 | 检查是否裸用 requests.get；图片代理必须复用 session 并带 `proxies=self.session.proxies or None` |
| Cloudflare/Next.js HTML 403 | 不直接判死站；先测 `/api/`、`__NEXT_DATA__`、移动 UA、Referer 和实测 cookie，API 可用则走 API |
| MissAV 系图片 AES 失败 | 检查 key/iv 是否 ASCII 16 字节、是否误用 bytes.fromhex、JPEG 是否截断到 `\xff\xd9` |
| 分类页空数据 | 优先重新分析；可用 `py_mcp:analyze_website`，否则用 Operit 网页/HTTP 工具和 `super_admin 终端` 检查选择器 |
| WordPress OneNav 导航站首页/推荐 0 条，且页面只聚合外部域名 | 装载 `strategies/wordpress_onenav_directory.md`；先判断是否导航目录站，停止 selector 三轮修复；请用户指定外链目标影视站 |
| 播放链接获取失败 | 优先 `py_mcp:debug_play_link`；不可用时按 JS/JSON/iframe/token 顺序递归调试 |
| 选择器匹配0个 | 优先 `py_mcp:debug_selector`；不可用时用 `super_admin 终端` 验证并检查 contains |
| 小说正文为空 | 检查内容区 XPath，多级兜底 |
| 图片不全 | 检查分页/data-src/data-original 懒加载 |
| 加密内容无法解密 | 优先分析工具识别加密类型；不可用时读取脚本并用 `super_admin 终端` 验证算法 |
| Nuxt 数据解析为空 | 检查 `__NUXT_DATA__`/payload 是否为索引数组；先还原再 `_walk` 字段，不套 XPath |
| 播放页有页面但无 `video_url` | 检查列表 `episode_id` 是否丢失；对比裸 ID 入口和带 episode_id 入口，后者可播则以列表入口为准 |
| folder 二级不能翻页 | `vod_tag:"folder"` 必须在 `categoryContent` 处理 `pg`，实测 `/page/2/` 或 `?page=2`，禁止固定 `pagecount=1` |
| 演员/专题列表加载很慢 | 检查是否逐条请求详情页补封面/备注；默认取消逐条请求，除非用户要求完整优先 |
| 图片 URL 有值但不显示 | 抽样请求检查 0 字节、Content-Type、magic bytes；必要时 localProxy 解密，不要返回 200 空图片 |
| 角标位置不对 | `vod_remarks` 只控制文本，位置由客户端 UI 控制，源无法强制左上/左下 |
| 页面只有 Vue/React 模板、博主列表为空 | 提取业务 JS，搜索 axios/fetch/$Http/listpagination，实测 JSON 接口和字段；游客接口失败不能清空公开数据 |
| 图片 URL 有值但封面不显示 | 检查 `z-image-loader-url`、Content-Type、响应长度和图片魔数；binary/octet-stream 需读取前端解密器并由 localProxy 解密 |
| `data-config` 播放数组为空 | 先将 HTML 的 quot、amp、apos 实体编码解码，再还原 JSON 路径中的反斜杠斜线，最后解析 JSON |
| 相对时间角标错误 | 移动端相对时间优先于桌面端绝对日期，依次支持刚刚、秒、分钟、小时、天、周、月、年 |
| 排行榜筛选无效 | 把筛选值映射到站点真实路径或接口参数，抽测默认、日、周、月及点赞/收藏项 |
| `parse:0` 播放失败 | 播放地址必须实测 HTTP、Content-Type 和媒体内容；M3U8 必须包含 `#EXTM3U`，HTML 播放页不能直接标记为直链 |
| JSON API站 | 使用采集API骨架，跳过HTML解析 |
| 搜索编码问题 | 关键词必须quote() |
| iframe播放器空白 | 二次请求iframe src提取m3u8 |
| 签名过期 | 检查API签名算法，添加时间戳参数 |
| 羊壳推荐页空/只有推荐页 | 加载 `strategies/yk_runtime.md`；检查 `homeVideoContent`、`homeContent.class`、filters dict、标准签名和翻页字段 |
| Nuxt/Next/Vite API 字段错 | 加载 `strategies/nuxt_devalue_api.md`；先还原 devalue/挖 chunk/config.js，再验证分类参数是否真的生效 |
| HLS 主 m3u8 200 但不能播 | 加载 `strategies/hls_localproxy.md`；逐级测主清单、子清单、key、ts，必要时 localProxy 重写 |
| data-preview/data-play-src 播放错片 | 列表直链站不要详情页二次抓第一个播放属性；将列表直链编码进 play id 并在 playerContent 直出 |
| 苹果CMS主分类空/补图缺前几条 | 加载 `strategies/applecms_api.md`；主分类轮询子分类，`ac=detail&ids=` 按 20 条分批并按 vod_id 回填 |
| 苹果CMS搜索验证码 | 先测 `/index.php/ajax/suggest?mid=1&wd={key}&limit=50`；无真实分页时不要伪造 pagecount |
| 发布页解出域名但列表空 | 加载 `strategies/domain_release.md`；验证目标站结构，防止发布页被其他站占用或 200 假成功 |
| folder 点击直接播放/不进二级 | 加载 `strategies/folder_routing.md`；folder 项必须 `vod_tag=folder`，并由 `categoryContent` 分发 |
| 加密 API 参数错误/401 | 加载 `strategies/encrypted_api.md`；检查 base64 URL 编码、header 大小写、guest token、成人确认流程 |
| 站点返回验证页/403/503 | 加载 `strategies/shield_routing.md`；先分诊盾类型，做真内容校验（盾页词+站点词双判），请求间隔 ≥1.5s，Referer 用触发页，优先走手机网络 |
| `huadong_*.js` 滑动验证 | 加载 `strategies/slider_huadong.md`；md5(每字符 charCode+1)；拉 JS/打验证接口都要带触发页 Referer |
| 每次翻页/搜索都重探域名（很慢） | 加载 `strategies/tvbox_runtime.md`；域名缓存必须写 `type(self)._HOST_CACHE`，不能用 `self._HOST_CACHE` |
| 搜索设置/页码档位设了不生效 | 加载 `strategies/search_agg_menu.md`；状态提为模块级；精确 `==` 分支先于 `startswith`；勾选即置 `sel` |
| 并发探活命中域名不是候选里排最前 | 加载 `strategies/tvbox_runtime.md`；用 `ex.map()` 保序，不用 `as_completed()` |
| 桌面 UA 拿到跳转壳页 | 加载 `strategies/tvbox_runtime.md`；强制 Android UA（站点 isPC 检测） |
| 多站/多线路聚合搜索、副标题标来源 | 加载 `strategies/search_agg_menu.md`；`{站名}｜原remark｜①~⑩`；N 站 × M 页 |
| XBPQ JSON 转 Python、一级二级筛选失效 | 加载 `strategies/xbpq_mapping.md`；同 tid 多组同 key，`ext['sort']` 统一消费 |
| 页面 HTML 是单引号包裹超长串 | 加载 `strategies/nonvideo_playext.md`；双重 base64 解码后再解析 |
| 图片返回非图片魔数（XOR 站） | 加载 `strategies/nonvideo_playext.md`；b64 文本逐字节 XOR，解密后查魔数 |
| 播放需 POST 接口取密文 | 加载 `strategies/nonvideo_playext.md`；POST 后取 JSON.u → b64 → 实测 `#EXTM3U` |
| 详情页 0 个 dplayer（专辑） | 加载 `strategies/nonvideo_playext.md`；先数容器，为 0 才走子链并发，不嗅探 |

---

# 完成前验证矩阵

- 分类：至少测主分类第1页、第2页；不要用 99/999 伪分页冒充。
- folder：每一种 `vod_tag:"folder"` 至少测 `categoryContent(folder_id,1)` 和 `categoryContent(folder_id,2)`；返回真实 `pagecount/total/limit`。
- 播放：列表项带 `episode_id` 的站点，确认 `vod_id` 保留 episode_id；抽测同一资源的裸 ID 入口和带 episode_id 入口，若裸入口坏但带 episode_id 返回 `video_url`，以列表 episode 入口为准。
- 图片：抽测普通封面、演员头像/封面、本地代理图片；检查返回长度 > 0 且 magic bytes 正确。
- 代理：被墙或 shell 端异常站点，确认 `_get/_post/playerContent/localProxy/proxyPic` 都复用同一 `session` 和代理；禁止写死私人代理 IP、NAS、账号、密码。
- Cloudflare/API：HTML 被 WAF 时，确认已尝试 API 优先、移动 UA、Referer/cookie；API 可用时报告“HTML 有 WAF，数据走 API”。
- MissAV 图片：抽测 `localProxy/proxyPic` 返回长度 > 0，magic bytes 正确；AES key/iv 为 16 字节 ASCII，JPEG 解密后截断到 EOI。
- 性能：一级列表不应产生 N 条详情请求；日志不应在进入演员/专题列表时批量打印“详情/作品”。
- 原站坏内容：若原站同入口本身无源或无数据，记录为站点数据问题，不做污染全局逻辑的特殊硬编码。
- 羊壳运行时：必须测 `homeVideoContent()`、`homeContent(False)` 和一个分类入口，确认 class/list/filters 类型符合壳端。
- Nuxt/API：必须验证 API base、字段路径、分类参数差异、分页 cursor/offset/page 机制。
- HLS：必须测主 m3u8、子 m3u8、key、ts；签名过期链接必须点击实时解析。
- 苹果CMS API：主分类为空时必须测子分类合并；补图按 20 条分批；suggest 搜索不伪造分页。
- 动态域名：解出的域名必须验证目标站结构，不只看 200；跳转链限制深度。
- Folder：每个 folder 类型至少测第 1/2 页，确认 `vod_tag` 和 `categoryContent` 分发。
- 加密 API：GET/POST 加密、响应解密、guest/confirm/playback 至少各测一次；locked 付费集跳过并报告。
- 盾对抗：必须先分诊盾类型并做真内容校验（盾页特征词 + 站点特征词双判），不得以 HTTP 200 判定过盾；滑动验证须验证「再请求目标页拿到真内容」；请求间隔 <1.5s 视为不合格。
- 运行时状态：域名缓存/搜索设置必须为类属性或模块级；实例重建后仍命中缓存；域名探测保序（`ex.map()`）；壳端用 Android UA 实测。
- 聚合搜索：三种模式（单搜/聚搜/组合搜）各测一次，请求次数 = N 站 × M 页；勾选即时生效；三清空各自回归默认。
- 双层筛选：同 tid 多组同 key 必须实测一级与二级值域各自生效，不得只测一级。
- XBPQ 转源：转后分类名单必须能与原站筛选栏第一组逐项对上。
- 非标准加密：整页双重 b64 解码后须含站点特征结构；XOR 图片解密后查魔数；POST 播放解密后实测 `#EXTM3U`；专辑三形态各有实测样本。

---

# 211实战源经验速查表

| 场景 | 占比 | 快速方案 |
|------|------|----------|
| MacCMS v8标准站 | 40% | v8骨架，改host+分类 |
| MacCMS v10标准站 | 30% | v10骨架，改host+分类 |
| 采集API站 | 10% | API骨架，改api路径 |
| 非标准影视站 | 10% | 深度分析HTML结构，自定义XPath |
| 加密站（AES/XOR/RSA） | 5% | 加密模块+对应骨架 |
| 异步站（aiohttp） | 3% | 同步改写，requests替代 |
| 双源聚合站 | 2% | 两套API合并，$$$分隔 |

---
<!-- 演进: 2026-08-28 | 来源: 耐看点播线路与 sign 解密回归 | 类型: troubleshoot -->
## 播放线路与真直链门禁（v9.4）

- `vod_play_from` 与 `vod_play_url` 的 `$$$` 数量必须一致。
- 线路按详情页首次出现顺序输出，不按 sid 数值排序；抽样核对首集的 `player_aaaa.sid/from`。
- 线路名不得含 `选择播放源/播放线路/展开/收起`；内部 code 优先映射 `playerconfig.js.show`。
- 每条线路至少抽测首集；最终 URL 不得仍含 `/player/`、`/play/` 或详情页路径。
- 播放配置位于 HTML 属性时，先解码 quot、amp、apos 实体编码，再还原 JSON 路径中的反斜杠斜线，最后解析 JSON。
- `parse:0` 只能用于已确认的 HTTP/HTTPS 媒体地址；M3U8 必须实测返回 `#EXTM3U`，不能把 HTML 播放页冒充直链。
- 图片封面必须抽测响应长度和魔数；自定义 `z-image-loader-url` 图片需验证解密或本地代理后的真实 MIME。
- 相对时间角标优先使用移动端字段，桌面端绝对日期仅作回退。
- Vue/React 博主或榜单模板必须追踪业务 JS 的 JSON 接口，抽测分页和筛选参数。
- `parse:0` 只允许用于确认后的媒体 URL，禁止 `parse:0 + 播放页 URL` 冒充直链。
- 直链协议必须为 http/https；`yeerx://`、`mttby://` 等可疑协议视为解密失败。
- WordPress 图集优先验证 `featured_media` 批量补图、`content.rendered` 图片顺序、`_media_cache` 和 `_pic_cache` 命中；禁止列表逐条请求详情补封面。
- 图片 URL 审计必须统计全量唯一 URL，并检查最终状态码、Content-Type 和响应长度；不能以扩展名或单个样本判定可用。
- 图片二级分类只有在目标客户端实测不支持 folder 路由时才使用 `filters` 分离模式，且 `filters[type_id]` 必须是过滤器列表。
- 改源或优化源必须保留修改前行为基线，修改后回归比较条数、核心字段、线路数和最终媒体地址；写法差异本身不构成缺陷。
- HLS 必须继续验证 HTTP 与 `#EXTM3U`；时效签名链接点击时实时解析。
- 双向字符映射都不报错时，以媒体 URL 语义和资源响应判定正确方向。

建议回归表：`线路名 / sid / from / 集数 / 首集播放页 / 最终URL / HTTP / #EXTM3U`。
<!-- 演进: 2026-09-03 | 来源: 雪落影视 py源开发 | 类型: troubleshoot -->

## 分类体系判定门禁（新增）

定 `classes` 前必须先读分类页筛选区，按 `<dt>` 分组判定：

- 第一组（常叫「资源分类」「类型」）才是真实资源分类，通常只有 2~4 项 → 进 `classes`
- 其余组（影视类型/制片地区/上映时间/排序）→ 进 `filters`
- 导航菜单/「更多」面板里的几十个标签**通常是筛选项，不是分类**，只能当线索，不能直接当 `classes`

交付前自查：源里的分类名单，能否和原站筛选栏第一组逐项对上？对不上就是分类体系错了，用户一眼就能看出来。

## URL 构造门禁（新增）

- `type_id` 必须是纯 slug，不得含 `?`、`&`、`=`；带 query 的分类用 `self.tids` 映射表转换
- query 串一律以 `?` 开头拼接，不得写成 `"&" + ...`
- 空筛选值不得进 query（`area=&year=` 会让站点返回 0 条）
- 分页正则要容忍 Java 站的 `;jsessionid=`：用 `/(\d+)(?:[;?]|$)` 而非 `/(\d+)(?:\?|$)`
- 详情页路径优先找站点的规范短路径（如 `/v/{id}.htm`），别用列表 href 里带分类前缀的形式硬拼
- 剧集 play id 存**完整相对路径**，不要抽 ID 重拼固定前缀（同站可能同时存在 `/play/x.htm` 与 `/{cat}/play/x.htm` 两种形式）

## 依赖门禁（新增）

- 顶层 import 只允许标准库 + `requests`；`lxml` / `Crypto` / `bs4` 等按需 import 到函数内或 try/except 兜底
- AES/MD5 等加密逻辑必须提供纯 Python 兜底路径，并与 pycryptodome 做逐字节一致性比对
- 顶层 import 失败在客户端表现为**静默空白无报错**，是「什么都不显示」的第一嫌疑

## 入参矩阵回归（新增）

交付前必须跑参数矩阵，全部返回非空：

| 维度 | 取值 |
|---|---|
| tid | 每个 type_id，且 str 与 int 各一次 |
| pg | `1`（int）、`"2"`（str） |
| filter | `True` / `False` / `None` |
| extend | `{}`、dict、JSON 字符串、`""`、`None` |
| ids | list 与裸字符串各一次 |
## Next.js RSC/API 新增门禁
- 页面含 `self.__next_f.push` 或 `__next_f` 时，必须优先记录 RSC 还原结果；不得以全页 `/movie/` 链接数代替视频条数。
- 至少确认一个真实列表对象、一个详情对象和一个播放/episode 对象；RSC 数据不足时追踪业务 chunk/API，不硬套 MacCMS XPath。
- 加密 API 必须分别测试成功密文响应、明文错误响应、请求体封装和响应解密；错误码只能作为辅助证据。
- 分类、搜索、标签、排序、年份、语言参数必须通过首批 ID、total 或分页差异确认真实生效。
- 若播放地址具有随机 hash、签名或旧 key/ts 失效特征，必须在 `playerContent` 实时获取并验证 `#EXTM3U`、key 和首个 ts。
- `.bnc`/`.bin`/`application/octet-stream` 图片必须检查魔数、长度和真实格式；只验证文件头不得宣布完整解密成功。

## AI 写源修复硬门禁（v9.5.1 补丁，解决「缺少 Spider 类」死循环）

### 根因（建源工坊日志典型表现）
1. 技能目录名被编码成 `py#U5199#U6e90#U6280#U80fd`，宿主扫不到 →「没有可用的扫描目录」
2. 已识别 MacCMS/myui 仍「无匹配模块，用全文」→ 未装载 maccms 模板
3. 画像路由大量「未知」仍进入生成与真跑 → 首页 0 条
4. 修复轮重写文件时丢掉 `class Spider` → 静态校验三轮全挂「缺少 Spider 类」

### 强制规则（任何 Agent / 任何修复轮必须遵守）

**R1. 骨架不可删除**
- 文件顶层必须永远存在：
  from base.spider import Spider
  class Spider(Spider):
- 六接口签名不得删除：init getName homeContent homeVideoContent categoryContent detailContent searchContent playerContent
- 静态错误含「缺少 Spider 类」或「Spider 类未继承」时：禁止继续改业务逻辑；必须先恢复骨架再改选择器/路由。

**R2. 画像未就绪不得生成成品**
- 下列任一项仍为「未知/空」时，只允许输出侦察报告，禁止写交付源、禁止进入真跑六接口：
  - 列表页 URL 模式或列表选择器未实测
  - 详情页播放列表 URL 模式未实测
  - 播放地址提取路径（iframe / player_data / var now / API）未实测
- 仅确认「首页可访问 + 模板名」不算画像完成。

**R3. MacCMS / myui 分诊**
- 页面出现 myui-vodlist、mytheme、MacPlayer、/template/mytheme/、苹果 CMS 特征时，必须装载 templates/maccms.md，有则优先 templates/code/maccms_v10.py 或 maccms_v8.py
- 禁止在已识别 MacCMS 时走「无匹配模块，用全文」兜底生成。

**R4. 修复轮顺序**
1. static_check.py（不过则不真跑）
2. 若错误含 Spider 类 / 导入 / 六接口签名 → 只修骨架
3. 若真跑 0 条 → 只修列表选择器与分类 URL，不动播放
4. 若播放失败 → 只修 playerContent / _extract_play
5. 单轮只改一类问题；禁止整文件推倒重写

**R5. 最小可过静态骨架**
见 templates/code/spider_skeleton.py。修复轮检测到「缺少 Spider 类」时，以该文件为底回填已验证 host/选择器。


---
# v9.5.2 硬门禁补充

- 生成产物缺少 `class Spider`：**禁止**套本地骨架后交付；必须重新生成完整类。
- `homeVideoContent` / 分类真跑 0 条：未完成，继续修选择器或路由，不得宣称成功。
- 命中 mytheme / `?cates-` / `?vodss-` / `?plays-`：强制 `templates/code/maccms_mytheme.py`。
- 播放 URL 仍是播放页 HTML 路径：`parse` 不得为 0。
- 修复超过 3 轮仍 0 条：输出阻塞报告（HTML 片段 + 选择器命中数），停止自动保存。
