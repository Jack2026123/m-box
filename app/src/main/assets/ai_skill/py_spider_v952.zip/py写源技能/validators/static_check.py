#!/usr/bin/env python3
import argparse
import ast
import re
from pathlib import Path

SIGNATURES = {
    'init': ['self', 'extend'], 'getName': ['self'], 'homeContent': ['self', 'filter'],
    'homeVideoContent': ['self'], 'categoryContent': ['self', 'tid', 'pg', 'filter', 'extend'],
    'detailContent': ['self', 'ids'], 'searchContent': ['self', 'key', 'quick', 'pg'],
    'playerContent': ['self', 'flag', 'id', 'vipFlags']
}

def _is_main_guard(node):
    return isinstance(node, ast.If) and isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name) and node.test.left.id == '__name__' and any(isinstance(x, ast.Constant) and x.value == '__main__' for x in node.test.comparators)

def _inherits_spider(cls):
    return any((isinstance(x, ast.Name) and x.id == 'Spider') or (isinstance(x, ast.Attribute) and x.attr == 'Spider') for x in cls.bases)

def _number(node):
    return node.value if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) else None

def _literal_number(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float, str)):
        try: return int(node.value)
        except Exception: return None
    return None

def _empty_return(node):
    if not isinstance(node, ast.Return): return False
    v = node.value
    return v is None or (isinstance(v, (ast.Dict, ast.List, ast.Set, ast.Tuple)) and len(v.elts if hasattr(v, 'elts') else v.keys) == 0) or (isinstance(v, ast.Constant) and v.value in ('', None, False))

def check(path, final=False):
    try: text = path.read_text(encoding='utf-8')
    except Exception as e: return [f'文件读取失败: {e}'], []
    errors, warnings = [], []
    try: tree = ast.parse(text)
    except SyntaxError as e: return [f'语法错误: {e}'], warnings
    guarded = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Try):
            for child in ast.walk(n):
                if isinstance(child, (ast.Import, ast.ImportFrom)): guarded.add(id(child))
    top_imports = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom)) and id(n) not in guarded]
    for n in top_imports:
        names = ([((n.module or '').split('.')[0])] + [a.name.split('.')[0] for a in n.names]) if isinstance(n, ast.ImportFrom) else [a.name.split('.')[0] for a in n.names]
        if any(x in names for x in ('lxml', 'bs4', 'Crypto')): errors.append('存在顶层可选依赖导入，必须延迟导入或 try/except 兜底')
    classes = [n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Spider']
    if not classes: errors.append('缺少 Spider 类；修复时必须先恢复 templates/code/spider_skeleton.py 骨架，禁止整文件空白重写')
    else:
        cls = classes[0]
        if not _inherits_spider(cls): errors.append('Spider 类未继承基类 Spider')
        methods = {n.name: n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        for name, expected in SIGNATURES.items():
            if name not in methods:
                errors.append(f'缺少接口: {name}'); continue
            actual = [x.arg for x in methods[name].args.args]
            allowed = [expected]
            if name in ('init', 'searchContent'): allowed.append(expected[:-1])
            if actual not in allowed: errors.append(f'接口签名错误: {name}({", ".join(actual)})')
        node = methods.get('getName')
        if node and node.body and isinstance(node.body[0], ast.Return) and isinstance(node.body[0].value, ast.Attribute) and node.body[0].value.attr == 'name': errors.append('getName 不能 return self.name，壳端可能先调 getName 再 init')
        if not any(isinstance(n, ast.ImportFrom) and n.module == 'base.spider' and any(a.name == 'Spider' for a in n.names) for n in tree.body): errors.append('缺少 base.spider.Spider 导入')
    if re.search(r'@class\s*=', text, re.I): errors.append('存在精确 class XPath')
    if re.search(r'https?://(?:[^/]+\.)?(?:example\.(?:com|org|net)|test\.com|yoursite\.(?:com|net|org)|localhost)(?![A-Za-z0-9.-])', text, re.I): (errors if final else warnings).append('存在占位域名，交付前必须替换')
    for node in ast.walk(tree):
        if isinstance(node, ast.Dict):
            for key, value in zip(node.keys, node.values):
                k = key.value if isinstance(key, ast.Constant) else None; v = _literal_number(value)
                if k == 'pagecount' and v is not None and v >= 99: errors.append(f'存在伪分页值: {k}={v}')
                if k == 'total' and v in (99, 999): errors.append(f'存在伪分页值: {k}={v}')
        if isinstance(node, ast.Assign):
            value = _literal_number(node.value)
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == 'pagecount' and value is not None and value >= 99: errors.append(f'存在伪分页值: {target.id}={value}')
                if isinstance(target, ast.Name) and target.id == 'total' and value in (99, 999): errors.append(f'存在伪分页值: {target.id}={value}')
    if "type('R'" in text or 'type("R"' in text: errors.append('存在半截假 Response 对象')
    if re.search(r'except[^\n]*:\s*return\s+data', text): errors.append('异常时返回原始密文/乱码')
    if re.search(r'except[^\n]*:\s*return\s+dec', text): errors.append('异常时返回未去尾噪解密块')
    if 'final.strip().startswith' in text: errors.append('decode_page HTML 判断过窄')
    if any(_is_main_guard(n) for n in tree.body): errors.append('存在 __main__ 测试块')
    if re.search(r'parse["\']\s*[:=]\s*0', text) and not any(x in text for x in ('#EXTM3U', '_probe_media', '_validate_media')): errors.append('parse:0 缺少真直链验证门禁')
    if re.search(r'vod_play_from', text) and re.search(r'vod_play_url', text) and 'join(fs)' in text and 'join(us)' in text and 'len(fs)' not in text: warnings.append('线路数量一致性未在模板代码中显式校验')
    if re.search(r'pagecount\s*["\']?\s*[:=]\s*1\s*(?:[,}\n]|$)', text): errors.append('存在固定 pagecount=1')
    if re.search(r'vod_play_from\s*=\s*["\'][^"\']*(?:选择播放源|播放线路|展开|收起)', text): errors.append('线路名包含界面提示词')
    if re.search(r'\b(?:yeerx|mttby)://', text, re.I): errors.append('存在伪协议播放地址')
    if re.search(r'\burlopen\s*\(', text) or re.search(r'^(?:from|import)\s+urllib\.request(?:\.|\s)', text, re.M): errors.append('存在绕过 session 的 urllib 请求')
    if re.search(r'parse\s*["\']?\s*[:=]\s*0[^\n]*(?:/play/|/player/|/detail/)', text, re.I): errors.append('parse:0 仍直接返回播放页路径')
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == 'requests' and node.func.attr in ('get', 'post'): errors.append('存在裸 requests 请求，必须复用 session')
    if classes:
        methods = {n.name: n for n in classes[0].body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
        for name in SIGNATURES:
            node = methods.get(name)
            if not node: continue
            body = list(node.body)
            if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str): body = body[1:]
            if len(body) == 1 and (_empty_return(body[0]) or isinstance(body[0], ast.Pass)): errors.append(f'接口为空壳: {name}')
    
    # v9.5.2 hard gates
    if "class Spider" not in text and "class Spider(" not in text:
        errors.append("FATAL: 源文件未包含 class Spider，禁止交付")
    if "homeVideoContent" not in text:
        errors.append("FATAL: 缺少 homeVideoContent")
    if "spider_skeleton" in text.lower() or "本地骨架" in text:
        errors.append("FATAL: 检测到骨架回退标记，禁止交付")
    if "/index.php/vod/" in text and ("?cates-" in text or "?vodss-" in text or "myui-vodlist" in text):
        warnings.append("同时存在标准路径与非标准路由特征，请确认实测路径")

    return list(dict.fromkeys(errors)), list(dict.fromkeys(warnings))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('root', nargs='?', default=str(Path(__file__).parent.parent / 'templates' / 'code'))
    ap.add_argument('--final', action='store_true', help='最终交付模式：占位域名等交付问题按错误处理')
    args = ap.parse_args(); root = Path(args.root)
    if not root.exists(): print(f'{root}: FAIL: 路径不存在'); raise SystemExit(1)
    paths = [root] if root.is_file() else sorted(root.rglob('*.py'))
    paths = [p for p in paths if '__pycache__' not in p.parts and 'archive' not in p.parts]
    if not paths: print(f'{root}: FAIL: 未找到 Python 源文件'); raise SystemExit(1)
    failed = 0
    for path in paths:
        errors, warnings = check(path, args.final); status = 'FAIL' if errors else 'WARN' if warnings else 'PASS'; details = errors + ['警告: ' + x for x in warnings]
        print(f'{path}: {status}' + (': ' + '; '.join(details) if details else '')); failed += bool(errors)
    raise SystemExit(1 if failed else 0)

if __name__ == '__main__': main()